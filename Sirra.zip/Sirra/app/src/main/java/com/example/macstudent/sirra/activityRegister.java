package com.example.macstudent.sirra;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class activityRegister extends AppCompatActivity implements View.OnClickListener {

    Button btnRegister;
    EditText editName;
    EditText editPhone;
    EditText editEmail;
    EditText editPassword;
    TextView txtDOB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        btnRegister = findViewById(R.id.btnRegister);
        editName = findViewById(R.id.editName);
        editPhone = findViewById(R.id.editPhone);
        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
        txtDOB = findViewById(R.id.txtDOB);
        txtDOB.setOnClickListener(this);

        btnRegister.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {

        if(v.getId() == btnRegister.getId()) {
            String data = editName.getText().toString() + "\n" + editPhone.getText().toString() + "\n" + editEmail.getText().toString() +
                    "\n" + editPassword.getText().toString() + "\n" + txtDOB.getText().toString();

            Toast.makeText(this, data, Toast.LENGTH_LONG).show();
            Intent loginIntent = new Intent(this,LoginActivity.class);
            startActivity(loginIntent);
        } else if(v.getId() == txtDOB.getId()){
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, datePickerListener,calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)).show();


        }

    }

    DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            String date = String.valueOf(month) + "/" + String.valueOf(dayOfMonth) + "/" + String.valueOf(year);
            txtDOB.setText(date);


        }
    };

}
