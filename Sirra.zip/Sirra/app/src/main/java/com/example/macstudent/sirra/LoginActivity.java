package com.example.macstudent.sirra;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnLogin;
    Button btnRegister;
    EditText editEmail;
    EditText editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);




    }

    @Override
    public void onClick(View v) {

        if(v.getId() == btnLogin.getId()) {
            String email = editEmail.getText().toString();
            String password = editPassword.getText().toString();

            if(email.equals("test") && password.equals("test")) {
                Toast.makeText(this, "Login Successfull", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Invalid Username/Password", Toast.LENGTH_SHORT).show();

            }
        }
        else if (v.getId() == btnRegister.getId()){
            Toast.makeText(this, "Register clicked", Toast.LENGTH_SHORT).show();

            Intent registerIntent = new Intent(this,activityRegister.class);
            startActivity(registerIntent);

        }


    }
}
